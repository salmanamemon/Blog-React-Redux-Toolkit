-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2022 at 09:16 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `crm_ticket_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `text` varchar(1500) NOT NULL,
  `image` varchar(50) NOT NULL DEFAULT '''blogimage.jpg''',
  `author_Id` int(11) NOT NULL,
  `cat_Id` int(11) NOT NULL,
  `added_At` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `posts`
--

INSERT INTO `posts` (`id`, `title`, `text`, `image`, `author_Id`, `cat_Id`, `added_At`) VALUES
(1, 'The AI magically removes moving objects from videos.', 'Jurna, non placerat justo pharetra elementum. Cras vulputate dignissim augue ac elementum. Nunc et nunc nec est tempor pellentesque ut eget eros. Vivamus maximus congue odio viverra fringilla. In ut mauris euismod, cursus nisi rhoncus, venenatis risus. Proin euismod tortor tortor, non hendrerit purus malesuada in. Quisque imperdiet nisi dignissim elit mattis, et eleifend sem luctus.\n\nVivamus turpis risus, molestie in mollis dignissim, dictum gravida est. Duis pulvinar risus in odio bibendum, si', 'blogimage.jpg', 1, 1, '2022-04-18 06:14:50'),
(2, 'The AI magically removes moving objects from videos.', 'Cu fringilla vulputate id ac diam. Vestibulum sapien enim, dignissim at auctor ac, accumsan eu nisi. Duis feugiat libero in efficitur tempus. Phasellus nibh tellus, faucibus vitae lorem pellentesque, malesuada porta leo. Etiam ac tortor orci. Vivamus tortor nulla, interdum dapibus ultrices non, blandit sed urna. Nulla volutpat metus ut ante consequat, at tincidunt diam euismod.\n\nNullam faucibus, massa in eleifend molestie, lorem tellus tincidunt ante, egestas cursus mauris ipsum et neque. Pr', 'blogimage.jpg', 2, 1, '2022-04-18 06:14:50'),
(3, 'The AI magically removes moving objects from videos.', 'Ere metus. Mauris iaculis blandit lobortis. In sodales in sem nec commodo. Donec sit amet turpis molestie eros fringilla lacinia. Nunc quis porta sapien, eget ornare mi. Vestibulum commodo eleifend diam a iaculis. Fusce ligula risus, luctus eget hendrerit quis, finibus nec erat. Donec ut sem vel neque convallis faucibus. Maecenas pulvinar, diam ac fermentum laoreet, dui odio congue arcu, ut cursus lectus quam ac velit. In hac habitasse platea dictumst. Mauris tincidunt et dui in tempus. Mauris ', 'blogimage.jpg', 3, 1, '2022-04-18 06:14:50'),
(4, 'The AI magically removes moving objects from videos.', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse efficitur varius urna, non placerat justo pharetra elementum. Cras vulputate dignissim augue ac elementum. Nunc et nunc nec est tempor pellentesque ut eget eros. Vivamus maximus congue odio viverra fringilla. In ut mauris euismod, cursus nisi rhoncus, venenatis risus. Proin euismod tortor tortor, non hendrerit purus malesuada in. Quisque imperdiet nisi dignissim elit mattis, et eleifend sem luctus.\r\n\r\nVivamus turpis risus, mole', 'blogimage.jpg', 4, 2, '2022-04-18 06:14:50'),
(5, 'The AI magically removes moving objects from videos.', 'Vivamus turpis risus, molestie in mollis dignissim, dictum gravida est. Duis pulvinar risus in odio bibendum, sit amet porta nisl fringilla. Etiam vitae tortor massa. Duis ut lectus mauris. Aenean vehicula in ipsum nec accumsan. Morbi ut elementum elit. Pellentesque eu metus pellentesque lorem interdum sagittis. Curabitur placerat arcu leo. Ut ut augue gravida, semper nibh eget, dictum quam. Mauris posuere dui ultricies sapien lacinia fringilla. Phasellus ullamcorper est ex, eget tristique tellu', 'blogimage.jpg', 1, 3, '2022-04-18 06:14:50'),
(6, 'The AI magically removes moving objects from videos.', 'Phasellus ullamcorper est ex, eget tristique tellus ultricies bibendum. Proin accumsan nulla sed eros blandit, non dictum odio mollis. Morbi suscipit orci et velit ultricies, luctus mattis tortor aliquam.\r\n\r\nProin sed tempor metus. Vestibulum at diam magna. Integer eu odio vel arcu fringilla vulputate id ac diam. Vestibulum sapien enim, dignissim at auctor ac, accumsan eu nisi. Duis feugiat libero in efficitur tempus. Phasellus nibh tellus, faucibus vitae lorem pellentesque, malesuada porta leo.', 'blogimage.jpg', 2, 4, '2022-04-18 06:14:50'),
(7, 'The AI magically removes moving objects from videos.', 'Is porta sapien, eget ornare mi. Vestibulum commodo eleifend diam a iaculis. Fusce ligula risus, luctus eget hendrerit quis, finibus nec erat. Donec ut sem vel neque convallis faucibus. Maecenas pulvinar, diam ac fermentum laoreet, dui odio congue arcu, ut cursus lectus quam ac velit. In hac habitasse platea dictumst. Mauris tincidunt et dui in tempus. Mauris interdum, sapien quis luctus hendrerit, turpis nibh gravida nibh, vel blandit nibh lectus ut mauris. Maecenas ullamcorper nec nunc vel com', 'blogimage.jpg', 3, 5, '2022-04-18 06:14:50'),
(8, 'The AI magically removes moving objects from videos.', 'Nisi. Duis feugiat libero in efficitur tempus. Phasellus nibh tellus, faucibus vitae lorem pellentesque, malesuada porta leo. Etiam ac tortor orci. Vivamus tortor nulla, interdum dapibus ultrices non, blandit sed urna. Nulla volutpat metus ut ante consequat, at tincidunt diam euismod.\n\nNullam faucibus, massa in eleifend molestie, lorem tellus tincidunt ante, egestas cursus mauris ipsum et neque. Praesent varius rutrum eros id euismod. Curabitur imperdiet felis eget urna ultricies faucibus. N', 'blogimage.jpg', 4, 6, '2022-04-18 06:14:50'),
(9, 'The AI magically removes moving objects from videos.', 'Rna, non placerat justo pharetra elementum. Cras vulputate dignissim augue ac elementum. Nunc et nunc nec est tempor pellentesque ut eget eros. Vivamus maximus congue odio viverra fringilla. In ut mauris euismod, cursus nisi rhoncus, venenatis risus. Proin euismod tortor tortor, non hendrerit purus malesuada in. Quisque imperdiet nisi dignissim elit mattis, et eleifend sem luctus.\n\nVivamus turpis risus, molestie in mollis dignissim, dictum gravida est. Duis pulvinar risus in odio bibendum, si', 'blogimage.jpg', 1, 1, '2022-04-18 06:14:50');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
